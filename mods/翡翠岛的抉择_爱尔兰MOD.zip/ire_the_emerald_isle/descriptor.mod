﻿name="翡翠岛的抉择 - 爱尔兰国策树"
version="2.9.9"
tags={
	"Alternative History"
	"National Focuses"
	"Historical"
}
supported_version="1.19.*"
